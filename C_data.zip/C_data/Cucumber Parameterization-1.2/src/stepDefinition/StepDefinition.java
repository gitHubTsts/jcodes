package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;


public class StepDefinition {

	WebDriver driver;
	String text;

	@Given("^User navigates to Shipping Details home page$")
	public void setUp(){		
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/shippingDetails/");
		System.out.println("Application is launched");
	}

	@When("^User clicks on (\\d+) link$")
	public void testShippingDetails(String ShipmentID) {
		text = driver.findElement(By.tagName("h2")).getText().trim();
		if(text.contentEquals("Shipping Details")){
			System.out.println(text +" is present in h2 tag");
		}
		else{
			System.out.println("h2 tag is not dislpayed correctly");
		}
		driver.findElement(By.linkText(ShipmentID)).click();
		if(driver.findElement(By.id("result")).isDisplayed())
			System.out.println("Shipment details of "+ShipmentID+" are displayed.");
		else
			System.out.println("Shipment details are not displayed.");
	}

	@Then("^Validate the \"([^\"]*)\" is displayed on the Shipping Details page$")
	public void validateResult(String CustomerName) {
		text = driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]")).getText().trim();
		if(text.contains(CustomerName)){
			System.out.println( CustomerName+" is present  in the table.");
		}
		driver.quit();
	}

}


