package stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.*;
import cucumber.api.java.en.*;


public class StepDefinition {

	WebDriver driver;
	String text,Name;

	@Before
	public void setUp(){		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Given("^User loads the application and navigate to Address book home page$")
	public void SetUp(){
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/AddressBook/");
		System.out.println("Application is launched");
	}

	@When("^User enters following details and clicks on Add button$")
	public void testAddressBook(DataTable addressDetails) {
		List<List<String>> data = addressDetails.raw();
		
			driver.findElement(By.id("nickname")).sendKeys(data.get(1).get(0));
			driver.findElement(By.id("contact")).sendKeys(data.get(1).get(1));
			driver.findElement(By.id("company")).sendKeys(data.get(1).get(2));
			driver.findElement(By.id("city")).sendKeys(data.get(1).get(3));
			driver.findElement(By.id("country")).sendKeys(data.get(1).get(4));
			driver.findElement(By.id("type")).sendKeys(data.get(1).get(5));
			driver.findElement(By.id("add")).click();
		}
	

	@When("^User selects \"([^\"]*)\" radio button for action$")
	public void testAddressBook(String Name, DataTable action){
		text = driver.findElement(By.xpath("//div[@id='result']//..//tr[2]")).getText();
		System.out.println(text);
		if(text.contains(Name)){
			driver.findElement(By.id("radio0")).click();
		}
		List<List<String>> data = action.raw();
		String value = data.get(1).get(0);
		System.out.println(Name+" is selected for " +value);
		if("Edit".contains(value)){
			driver.findElement(By.id("edit")).click();
			driver.findElement(By.id("company")).clear();
			driver.findElement(By.id("company")).sendKeys("TCS");
			driver.findElement(By.id("add")).click();
		}
		if("Delete".contains(value)){
			driver.findElement(By.id("delete")).click();
		}	
	}

	@Then("^customer details should be displayed based on the results$")
	public void validateResult(DataTable action)
	{
		if(driver.findElement(By.xpath("//div[@id='result']/table")).isDisplayed())
		{
			List<List<String>> data = action.raw();
			String value = data.get(1).get(0);
			if("Add".contains(value))
			{
				String validText = driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]")).getText();
				System.out.println(validText+ " are displayed");
			}
			if("Edit".contains(value))
			{
				String validText = driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]/td[3]")).getText();
				if(validText.equalsIgnoreCase("TCS"))
				{
					System.out.println("Company name updated successfully");
				}
			}
			if("Delete".contains(value)){
					System.out.println("Address Details are deleted ");
			}
		}
	}
	@After
	public void tearDown(){
		driver.quit();
	}
}


