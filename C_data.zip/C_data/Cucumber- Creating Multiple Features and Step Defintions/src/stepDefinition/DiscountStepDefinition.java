package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;


public class DiscountStepDefinition {

	WebDriver driver;
	String text;


	@Given("^User launches the application and DATAX shipping company home page appears$")
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CompanyOffersDiscount/");
		System.out.println("Application is launched");
	}

	@When("^User enters \"([^\"]*)\" and \"([^\"]*)\" on Company Offers Discount page$")
	public void testDiscount(String weight, String distance) {	
		driver.findElement(By.id("weight")).sendKeys(weight);
		driver.findElement(By.id("distance")).sendKeys(distance);
		driver.findElement(By.id("submit")).click();
	}

	@Then("^The text \"([^\"]*)\" should be displayed$")
	public void validateResult(String Message) {
		text = driver.findElement(By.xpath("//div[@id='result']")).getText();
		if (text.contains(Message)){
			System.out.println("The text "+text+" is displayed");
		}
		else{
			System.out.println("The text "+text+" is not displayed");
		}
		driver.quit();
	}

}


