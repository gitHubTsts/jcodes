package stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.DataTable;
import cucumber.api.java.*;
import cucumber.api.java.en.*;



public class StepDefinition {

	WebDriver driver;
	String text;
	String value;

	@Given("^User launches the application and Customer Form page appears$")
	public void setUp(){		
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CustomerRegistration/Index ");
		System.out.println("Application is launched");
	}

	@When("^User enters below details and clicks on Submit or Reset button$")
	public void testCustomerRegistration(DataTable customerDetails){
		List<List<String>> data= customerDetails.raw();
		String Name = data.get(1).get(0);
		String Age = data.get(1).get(1);
		String Address = data.get(1).get(2);
		String PhoneNumber = data.get(1).get(3);
		String Email = data.get(1).get(4);
		value = data.get(1).get(5);

		driver.findElement(By.name("cname")).sendKeys(Name);
		driver.findElement(By.name("age")).sendKeys(Age);
		driver.findElement(By.name("address")).sendKeys(Address);
		driver.findElement(By.name("phonenumber")).sendKeys(PhoneNumber);
		driver.findElement(By.name("email")).sendKeys(Email);
		System.out.println(Name+" "+Age+" "+Address+" "+PhoneNumber+" "+Email+" are passed");
		if(value.equals("Submit")){
			driver.findElement(By.id("submit")).click();
		}
		if(value.equals("Reset")){
			driver.findElement(By.id("reset")).click();
			
		}
	}

	@Then("^appropriate message should be displayed$")
	public void validateResult() {
		text = driver.findElement(By.tagName("h2")).getText();
	if("Reset".equals(value)){
		Assert.assertEquals("", driver.findElement(By.name("cname")).getText());
		Assert.assertEquals("", driver.findElement(By.name("age")).getText());
		Assert.assertEquals("", driver.findElement(By.name("address")).getText());
		Assert.assertEquals("", driver.findElement(By.name("phonenumber")).getText());
		Assert.assertEquals("", driver.findElement(By.name("email")).getText());
		System.out.println("Reset Successful");
	}
	else if(text.equalsIgnoreCase("Registered Succesfully")){
			text = driver.findElement(By.xpath("//tbody")).getText();
			System.out.println(text+" are displayed.");
		}
		else{
			if(driver.findElement(By.id("message")).isDisplayed()){
					text = driver.findElement(By.id("message")).getText();
					if(text.contains("Customer name cannot be blank")||text.contains("Age cannot be blank")||text.contains("Address cannot be blank")
							||text.contains("phoneNumber cannot be blank")||text.contains("Email cannot be blank")||text.contains("Enter a valid email id")){
						System.out.println(text+" is displayed on passing blank values");
					}
				}
			}
		}

	@After
	public void tearDown(){
		driver.quit();
	}

}


