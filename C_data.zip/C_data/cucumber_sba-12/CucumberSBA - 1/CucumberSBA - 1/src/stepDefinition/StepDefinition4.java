package stepDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition4 {

	WebDriver driver;

	@Given("^initialize the firefox driver, and navigate to the shipment page4$")
	public void initialize_the_firefox_driver_and_navigate_to_the_shipment_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\E-box\\Cucumber\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CucumberShipmentPagination/filter.do?page=1#blah ");

	}

	@When("^get the page4 element and click on it$")
	public void get_the_page_element_and_click_on_it()  {
		driver.findElement(By.xpath("//a[text()='4']")).click();
		try {
			driver.wait(1000);
		} catch (Exception e) {

		}

	}

	@Then("^verify if the element present with tag4 and the related data are present and close the driver with quit method$")
	public void verify_if_the_element_present_with_tag_and_the_related_data_are_present_and_close_the_driver_with_quit_method(DataTable table) throws Throwable {
		List<List<String>> data = table.raw();
		List<WebElement> tableRowData = driver.findElements(By.xpath("//table/tbody/tr"));
		List<String> retrievedData;
		for(int i=2; i<= tableRowData.size(); i++) {
			retrievedData = new ArrayList<String>();
			List<WebElement> tableColumnData = driver.findElements(By.xpath("//table/tbody/tr["+i+"]/td"));
			for(int j=1; j<=tableColumnData.size();j++) {
				retrievedData.add(driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td["+j+"]")).getText());
			}
			Assert.assertEquals(retrievedData, data.get(i-1));
		}
		driver.quit();
	}

}
