package stepDefinition;

import java.util.concurrent.TimeUnit;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	WebDriver driver;

	@Given("^initialize the firefox driver, and navigate to the index page$")
	public void initialize_the_firefox_driver_and_navigate_to_the_index_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\E-box\\Cucumber\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CucumberHostelFeeCalc/");
	}

	@When("^verify the all form fields with name as \"([^\"]*)\", \"([^\"]*)\" , \"([^\"]*)\" and button with id as \"([^\"]*)\", then click the  'get total fee' button$")
	public void verify_the_all_form_fields_with_name_as_and_button_with_id_as_then_click_the_get_total_fee_button(String name, String type, String number, String button) throws Throwable {

		Assert.assertEquals(driver.findElement(By.name(name)), driver.findElement(By.name("name")));
		Assert.assertEquals(driver.findElement(By.name(type)), driver.findElement(By.name("type")));
		Assert.assertEquals(driver.findElement(By.name(number)), driver.findElement(By.name("number")));
		Assert.assertEquals(driver.findElement(By.name(button)), driver.findElement(By.name("getFee")));

	}

	@Then("^test all the scenarios specified below with tag \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"and \"([^\"]*)\" and close the driver with quit method$")
	public void test_all_the_scenarios_specified_below_with_tag_and_and_and_and_and_and_close_the_driver_with_quit_method(String studentType, String studentPerRoom, String collegeFee, String hostelFee, String additionalFee, String totalFee) throws Throwable {


		if(studentType.equals("Day Scholar") && studentPerRoom.equals("0")) {
			driver.findElement(By.name("name")).sendKeys("Keerthi");
			driver.findElement(By.xpath("//*[@name='type' and @value = 'day-scholar']")).click();
			driver.findElement(By.name("number")).sendKeys("--");
			driver.findElement(By.name("getFee")).click();


			Assert.assertEquals(collegeFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[1]/td[2]")).getText()); 
			Assert.assertEquals("--", driver.findElement(By.xpath("//*[@id='feeTable']//tr[2]/td[2]")).getText());
			Assert.assertEquals("--", driver.findElement(By.xpath("//*[@id='feeTable']//tr[3]/td[2]")).getText());
			Assert.assertEquals(totalFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[4]/td[2]")).getText());

			

		}
		else if(studentType.equals("Hosteller") && studentPerRoom.equals("1")) {
			driver.findElement(By.name("name")).sendKeys("Keerthi");
			driver.findElement(By.xpath("//*[@name='type' and @value = 'hosteller']")).click();
			driver.findElement(By.name("number")).sendKeys("1");
			driver.findElement(By.name("getFee")).click();
			
			Assert.assertEquals(collegeFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[1]/td[2]")).getText()); 
			Assert.assertEquals(hostelFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[2]/td[2]")).getText());
			Assert.assertEquals(additionalFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[3]/td[2]")).getText());
			Assert.assertEquals(totalFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[4]/td[2]")).getText());
		
			

		}
		else if(studentType.equals("Hosteller") && studentPerRoom.equals("2")) {
			driver.findElement(By.name("name")).sendKeys("Keerthi");
			driver.findElement(By.xpath("//*[@name='type' and @value = 'hosteller']")).click();
			driver.findElement(By.name("number")).sendKeys("2");
			driver.findElement(By.name("getFee")).click();

			Assert.assertEquals(collegeFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[1]/td[2]")).getText()); 
			Assert.assertEquals(hostelFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[2]/td[2]")).getText());
			Assert.assertEquals(additionalFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[3]/td[2]")).getText());
			Assert.assertEquals(totalFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[4]/td[2]")).getText());

		}
		else if(studentType.equals("Hosteller") && studentPerRoom.equals("3")) {
			driver.findElement(By.name("name")).sendKeys("Keerthi");
			driver.findElement(By.xpath("//*[@name='type' and @value = 'hosteller']")).click();
			driver.findElement(By.name("number")).sendKeys("3");
			driver.findElement(By.name("getFee")).click();

			Assert.assertEquals(collegeFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[1]/td[2]")).getText()); 
			Assert.assertEquals(hostelFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[2]/td[2]")).getText());
			Assert.assertEquals("--", driver.findElement(By.xpath("//*[@id='feeTable']//tr[3]/td[2]")).getText());
			Assert.assertEquals(totalFee, driver.findElement(By.xpath("//*[@id='feeTable']//tr[4]/td[2]")).getText());
		
		}
		driver.quit();
	}
	
}
