$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CollegeFee.feature");
formatter.feature({
  "id": "calculation-of-total-fees",
  "description": "",
  "name": "Calculation of Total Fees",
  "keyword": "Feature",
  "line": 1
});
formatter.scenarioOutline({
  "id": "calculation-of-total-fees;test-the-fee-details",
  "description": "",
  "name": "Test the Fee Details",
  "keyword": "Scenario Outline",
  "line": 3,
  "type": "scenario_outline"
});
formatter.step({
  "name": "initialize the firefox driver, and navigate to the index page",
  "keyword": "Given ",
  "line": 4
});
formatter.step({
  "name": "verify the all form fields with name as \"name\", \"type\" , \"number\" and button with id as \"getFee\", then click the  \u0027get total fee\u0027 button",
  "keyword": "When ",
  "line": 5
});
formatter.step({
  "name": "test all the scenarios specified below with tag \"\u003cStudent Type\u003e\" and \"\u003cStudents per room\u003e\" and \"\u003cCollege Fee\u003e\" and \"\u003cHostel Fee\u003e\" and \"\u003cAdditional Fee\u003e\"and \"\u003cTotal Fee\u003e\" and close the driver with quit method",
  "keyword": "Then ",
  "line": 6
});
formatter.examples({
  "id": "calculation-of-total-fees;test-the-fee-details;",
  "description": "",
  "name": "",
  "keyword": "Examples",
  "line": 8,
  "rows": [
    {
      "id": "calculation-of-total-fees;test-the-fee-details;;1",
      "cells": [
        "Student Type",
        "Students per room",
        "College Fee",
        "Hostel Fee",
        "Additional Fee",
        "Total Fee"
      ],
      "line": 9
    },
    {
      "id": "calculation-of-total-fees;test-the-fee-details;;2",
      "cells": [
        "Day Scholar",
        "0",
        "Rs.120000.0",
        "0",
        "0",
        "Rs.120000.0"
      ],
      "line": 10
    },
    {
      "id": "calculation-of-total-fees;test-the-fee-details;;3",
      "cells": [
        "Hosteller",
        "1",
        "Rs.120000.0",
        "Rs.75750.0",
        "Rs.30300.0",
        "Rs.226050.0"
      ],
      "line": 11
    },
    {
      "id": "calculation-of-total-fees;test-the-fee-details;;4",
      "cells": [
        "Hosteller",
        "2",
        "Rs.120000.0",
        "Rs.75750.0",
        "Rs.15150.0",
        "Rs.210900.0"
      ],
      "line": 12
    },
    {
      "id": "calculation-of-total-fees;test-the-fee-details;;5",
      "cells": [
        "Hosteller",
        "3",
        "Rs.120000.0",
        "Rs.75750.0",
        "0",
        "Rs.195750.0"
      ],
      "line": 13
    }
  ]
});
formatter.scenario({
  "id": "calculation-of-total-fees;test-the-fee-details;;2",
  "description": "",
  "name": "Test the Fee Details",
  "keyword": "Scenario Outline",
  "line": 10,
  "type": "scenario"
});
formatter.step({
  "name": "initialize the firefox driver, and navigate to the index page",
  "keyword": "Given ",
  "line": 4
});
formatter.step({
  "name": "verify the all form fields with name as \"name\", \"type\" , \"number\" and button with id as \"getFee\", then click the  \u0027get total fee\u0027 button",
  "keyword": "When ",
  "line": 5
});
formatter.step({
  "name": "test all the scenarios specified below with tag \"Day Scholar\" and \"0\" and \"Rs.120000.0\" and \"0\" and \"0\"and \"Rs.120000.0\" and close the driver with quit method",
  "keyword": "Then ",
  "line": 6,
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ]
});
formatter.match({
  "location": "StepDefinition.initialize_the_firefox_driver_and_navigate_to_the_index_page()"
});
formatter.result({
  "duration": 6049876913,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "name",
      "offset": 41
    },
    {
      "val": "type",
      "offset": 49
    },
    {
      "val": "number",
      "offset": 58
    },
    {
      "val": "getFee",
      "offset": 89
    }
  ],
  "location": "StepDefinition.verify_the_all_form_fields_with_name_as_and_button_with_id_as_then_click_the_get_total_fee_button(String,String,String,String)"
});
formatter.result({
  "duration": 237940710,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Day Scholar",
      "offset": 49
    },
    {
      "val": "0",
      "offset": 67
    },
    {
      "val": "Rs.120000.0",
      "offset": 75
    },
    {
      "val": "0",
      "offset": 93
    },
    {
      "val": "0",
      "offset": 101
    },
    {
      "val": "Rs.120000.0",
      "offset": 108
    }
  ],
  "location": "StepDefinition.test_all_the_scenarios_specified_below_with_tag_and_and_and_and_and_and_close_the_driver_with_quit_method(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 3114698456,
  "status": "passed"
});
formatter.scenario({
  "id": "calculation-of-total-fees;test-the-fee-details;;3",
  "description": "",
  "name": "Test the Fee Details",
  "keyword": "Scenario Outline",
  "line": 11,
  "type": "scenario"
});
formatter.step({
  "name": "initialize the firefox driver, and navigate to the index page",
  "keyword": "Given ",
  "line": 4
});
formatter.step({
  "name": "verify the all form fields with name as \"name\", \"type\" , \"number\" and button with id as \"getFee\", then click the  \u0027get total fee\u0027 button",
  "keyword": "When ",
  "line": 5
});
formatter.step({
  "name": "test all the scenarios specified below with tag \"Hosteller\" and \"1\" and \"Rs.120000.0\" and \"Rs.75750.0\" and \"Rs.30300.0\"and \"Rs.226050.0\" and close the driver with quit method",
  "keyword": "Then ",
  "line": 6,
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ]
});
formatter.match({
  "location": "StepDefinition.initialize_the_firefox_driver_and_navigate_to_the_index_page()"
});
formatter.result({
  "duration": 4806318421,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "name",
      "offset": 41
    },
    {
      "val": "type",
      "offset": 49
    },
    {
      "val": "number",
      "offset": 58
    },
    {
      "val": "getFee",
      "offset": 89
    }
  ],
  "location": "StepDefinition.verify_the_all_form_fields_with_name_as_and_button_with_id_as_then_click_the_get_total_fee_button(String,String,String,String)"
});
formatter.result({
  "duration": 135408784,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Hosteller",
      "offset": 49
    },
    {
      "val": "1",
      "offset": 65
    },
    {
      "val": "Rs.120000.0",
      "offset": 73
    },
    {
      "val": "Rs.75750.0",
      "offset": 91
    },
    {
      "val": "Rs.30300.0",
      "offset": 108
    },
    {
      "val": "Rs.226050.0",
      "offset": 124
    }
  ],
  "location": "StepDefinition.test_all_the_scenarios_specified_below_with_tag_and_and_and_and_and_and_close_the_driver_with_quit_method(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 2326142914,
  "status": "passed"
});
formatter.scenario({
  "id": "calculation-of-total-fees;test-the-fee-details;;4",
  "description": "",
  "name": "Test the Fee Details",
  "keyword": "Scenario Outline",
  "line": 12,
  "type": "scenario"
});
formatter.step({
  "name": "initialize the firefox driver, and navigate to the index page",
  "keyword": "Given ",
  "line": 4
});
formatter.step({
  "name": "verify the all form fields with name as \"name\", \"type\" , \"number\" and button with id as \"getFee\", then click the  \u0027get total fee\u0027 button",
  "keyword": "When ",
  "line": 5
});
formatter.step({
  "name": "test all the scenarios specified below with tag \"Hosteller\" and \"2\" and \"Rs.120000.0\" and \"Rs.75750.0\" and \"Rs.15150.0\"and \"Rs.210900.0\" and close the driver with quit method",
  "keyword": "Then ",
  "line": 6,
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ]
});
formatter.match({
  "location": "StepDefinition.initialize_the_firefox_driver_and_navigate_to_the_index_page()"
});
formatter.result({
  "duration": 4765269667,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "name",
      "offset": 41
    },
    {
      "val": "type",
      "offset": 49
    },
    {
      "val": "number",
      "offset": 58
    },
    {
      "val": "getFee",
      "offset": 89
    }
  ],
  "location": "StepDefinition.verify_the_all_form_fields_with_name_as_and_button_with_id_as_then_click_the_get_total_fee_button(String,String,String,String)"
});
formatter.result({
  "duration": 146912710,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Hosteller",
      "offset": 49
    },
    {
      "val": "2",
      "offset": 65
    },
    {
      "val": "Rs.120000.0",
      "offset": 73
    },
    {
      "val": "Rs.75750.0",
      "offset": 91
    },
    {
      "val": "Rs.15150.0",
      "offset": 108
    },
    {
      "val": "Rs.210900.0",
      "offset": 124
    }
  ],
  "location": "StepDefinition.test_all_the_scenarios_specified_below_with_tag_and_and_and_and_and_and_close_the_driver_with_quit_method(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 2370174737,
  "status": "passed"
});
formatter.scenario({
  "id": "calculation-of-total-fees;test-the-fee-details;;5",
  "description": "",
  "name": "Test the Fee Details",
  "keyword": "Scenario Outline",
  "line": 13,
  "type": "scenario"
});
formatter.step({
  "name": "initialize the firefox driver, and navigate to the index page",
  "keyword": "Given ",
  "line": 4
});
formatter.step({
  "name": "verify the all form fields with name as \"name\", \"type\" , \"number\" and button with id as \"getFee\", then click the  \u0027get total fee\u0027 button",
  "keyword": "When ",
  "line": 5
});
formatter.step({
  "name": "test all the scenarios specified below with tag \"Hosteller\" and \"3\" and \"Rs.120000.0\" and \"Rs.75750.0\" and \"0\"and \"Rs.195750.0\" and close the driver with quit method",
  "keyword": "Then ",
  "line": 6,
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ]
});
formatter.match({
  "location": "StepDefinition.initialize_the_firefox_driver_and_navigate_to_the_index_page()"
});
formatter.result({
  "duration": 4261393518,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "name",
      "offset": 41
    },
    {
      "val": "type",
      "offset": 49
    },
    {
      "val": "number",
      "offset": 58
    },
    {
      "val": "getFee",
      "offset": 89
    }
  ],
  "location": "StepDefinition.verify_the_all_form_fields_with_name_as_and_button_with_id_as_then_click_the_get_total_fee_button(String,String,String,String)"
});
formatter.result({
  "duration": 127222096,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Hosteller",
      "offset": 49
    },
    {
      "val": "3",
      "offset": 65
    },
    {
      "val": "Rs.120000.0",
      "offset": 73
    },
    {
      "val": "Rs.75750.0",
      "offset": 91
    },
    {
      "val": "0",
      "offset": 108
    },
    {
      "val": "Rs.195750.0",
      "offset": 115
    }
  ],
  "location": "StepDefinition.test_all_the_scenarios_specified_below_with_tag_and_and_and_and_and_and_close_the_driver_with_quit_method(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 2398300175,
  "status": "passed"
});
});