$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Shipment1.feature");
formatter.feature({
  "line": 1,
  "name": "Click on page link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Click on page link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed;click-on-page-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "initialize the firefox driver, and navigate to the shipment page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "get the page element and click on it",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "verify if the element present with tag and the related data are present and close the driver with quit method",
  "rows": [
    {
      "cells": [
        "Name",
        "Status",
        "Weight",
        "Arrival Port",
        "Depature Port"
      ],
      "line": 7
    },
    {
      "cells": [
        "Computers",
        "Pending",
        "36542.0",
        "Shanghai",
        "Singapore"
      ],
      "line": 8
    },
    {
      "cells": [
        "Laptops",
        "Arrived",
        "13516.0",
        "Shenzhen",
        "HongKong"
      ],
      "line": 9
    },
    {
      "cells": [
        "Furnitures",
        "Delayed",
        "15653.0",
        "Ningbo",
        "Gangzhou"
      ],
      "line": 10
    },
    {
      "cells": [
        "Electronic wastes",
        "Pending",
        "68466.0",
        "Busan",
        "Qingdao"
      ],
      "line": 11
    },
    {
      "cells": [
        "Chairs",
        "Delayed",
        "16843.0",
        "Tainjin",
        "Dubai"
      ],
      "line": 12
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition1.initialize_the_firefox_driver_and_navigate_to_the_shipment_page()"
});
formatter.result({
  "duration": 5809133141,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition1.get_the_page_element_and_click_on_it()"
});
formatter.result({
  "duration": 77254703,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition1.verify_if_the_element_present_with_tag_and_the_related_data_are_present_and_close_the_driver_with_quit_method(DataTable)"
});
formatter.result({
  "duration": 2789659690,
  "status": "passed"
});
formatter.uri("Shipment2.feature");
formatter.feature({
  "line": 1,
  "name": "Click on page2 link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page2-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Click on page2 link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page2-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed;click-on-page2-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "initialize the firefox driver, and navigate to the shipment page2",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "get the page2 element and click on it",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "verify if the element present with tag2 and the related data are present and close the driver with quit method",
  "rows": [
    {
      "cells": [
        "Name",
        "Status",
        "Weight",
        "Arrival Port",
        "Depature Port"
      ],
      "line": 7
    },
    {
      "cells": [
        "Shoes",
        "Pending",
        "76516.0",
        "Rotterdam",
        "Klang"
      ],
      "line": 8
    },
    {
      "cells": [
        "Clothings",
        "Arrived",
        "16846.0",
        "Kaohsiung",
        "Dalian"
      ],
      "line": 9
    },
    {
      "cells": [
        "Mobile Phomes",
        "Delayed",
        "46863.0",
        "Hemburg",
        "Antwerp"
      ],
      "line": 10
    },
    {
      "cells": [
        "Chemical Wastes",
        "Pending",
        "46846.0",
        "Xiamen",
        "LosAngeles"
      ],
      "line": 11
    },
    {
      "cells": [
        "Television",
        "Delayed",
        "86563.0",
        "LongBeach",
        "TanjungPriok"
      ],
      "line": 12
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition2.initialize_the_firefox_driver_and_navigate_to_the_shipment_page()"
});
formatter.result({
  "duration": 4675895498,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.get_the_page_element_and_click_on_it()"
});
formatter.result({
  "duration": 217885708,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition2.verify_if_the_element_present_with_tag_and_the_related_data_are_present_and_close_the_driver_with_quit_method(DataTable)"
});
formatter.result({
  "duration": 2579119269,
  "status": "passed"
});
formatter.uri("Shipment3.feature");
formatter.feature({
  "line": 1,
  "name": "Click on page3 link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page3-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Click on page3 link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page3-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed;click-on-page3-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "initialize the firefox driver, and navigate to the shipment page3",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "get the page3 element and click on it",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "verify if the element present with tag3 and the related data are present and close the driver with quit method",
  "rows": [
    {
      "cells": [
        "Name",
        "Status",
        "Weight",
        "Arrival Port",
        "Depature Port"
      ],
      "line": 7
    },
    {
      "cells": [
        "Air Conditionar",
        "Arrived",
        "76865.0",
        "Breman",
        "NewYork"
      ],
      "line": 8
    },
    {
      "cells": [
        "Ceiling Fan",
        "Delayed",
        "46843.0",
        "Yingkou",
        "Lainyungang"
      ],
      "line": 9
    },
    {
      "cells": [
        "Refridgerator",
        "Pending",
        "35465.0",
        "Colambo",
        "Tokyo"
      ],
      "line": 10
    },
    {
      "cells": [
        "Water heater",
        "Delayed",
        "35489.0",
        "Algeciras",
        "Mumbai"
      ],
      "line": 11
    },
    {
      "cells": [
        "Home Theater",
        "Arrived",
        "98463.0",
        "Valencia",
        "Jedah"
      ],
      "line": 12
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition3.initialize_the_firefox_driver_and_navigate_to_the_shipment_page()"
});
formatter.result({
  "duration": 4885694661,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition3.get_the_page_element_and_click_on_it()"
});
formatter.result({
  "duration": 356073592,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition3.verify_if_the_element_present_with_tag_and_the_related_data_are_present_and_close_the_driver_with_quit_method(DataTable)"
});
formatter.result({
  "duration": 2592672262,
  "status": "passed"
});
formatter.uri("Shipment4.feature");
formatter.feature({
  "line": 1,
  "name": "Click on page4 link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page4-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Click on page4 link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page4-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed;click-on-page4-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "initialize the firefox driver, and navigate to the shipment page4",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "get the page4 element and click on it",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "verify if the element present with tag4 and the related data are present and close the driver with quit method",
  "rows": [
    {
      "cells": [
        "Name",
        "Status",
        "Weight",
        "Arrival Port",
        "Depature Port"
      ],
      "line": 7
    },
    {
      "cells": [
        "Bio Waste",
        "Delayed",
        "68465.0",
        "Felixstove",
        "PortSaid"
      ],
      "line": 8
    },
    {
      "cells": [
        "Irom Box",
        "Pending",
        "83546.0",
        "Sharjah",
        "Santos"
      ],
      "line": 9
    },
    {
      "cells": [
        "Mixer Grinder",
        "Arrived",
        "35466.0",
        "Piraeus",
        "Manila"
      ],
      "line": 10
    },
    {
      "cells": [
        "Cock",
        "Arrived",
        "46862.0",
        "Ambarli",
        "Savanah"
      ],
      "line": 11
    },
    {
      "cells": [
        "Washing Machine",
        "Pending",
        "43846.0",
        "Colon",
        "Balboa"
      ],
      "line": 12
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition4.initialize_the_firefox_driver_and_navigate_to_the_shipment_page()"
});
formatter.result({
  "duration": 4695138789,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition4.get_the_page_element_and_click_on_it()"
});
formatter.result({
  "duration": 180439954,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition4.verify_if_the_element_present_with_tag_and_the_related_data_are_present_and_close_the_driver_with_quit_method(DataTable)"
});
formatter.result({
  "duration": 2574643170,
  "status": "passed"
});
formatter.uri("Shipment5.feature");
formatter.feature({
  "line": 1,
  "name": "Click on page5 link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page5-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Click on page5 link of the pagination and the shipment details in page should be displayed",
  "description": "",
  "id": "click-on-page5-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed;click-on-page5-link-of-the-pagination-and-the-shipment-details-in-page-should-be-displayed",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "initialize the firefox driver, and navigate to the shipment page5",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "get the page5 element and click on it",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "verify if the element present with tag5 and the related data are present and close the driver with quit method",
  "rows": [
    {
      "cells": [
        "Name",
        "Status",
        "Weight",
        "Arrival Port",
        "Depature Port"
      ],
      "line": 7
    },
    {
      "cells": [
        "Table Fan",
        "Delayed",
        "68463.0",
        "Taicang",
        "Salalah"
      ],
      "line": 8
    },
    {
      "cells": [
        "Water Purifier",
        "Arrived",
        "46843.0",
        "Vancouver",
        "Yokohama"
      ],
      "line": 9
    },
    {
      "cells": [
        "Air cooler",
        "Pending",
        "65498.0",
        "Nanjing",
        "Nagoya"
      ],
      "line": 10
    },
    {
      "cells": [
        "Medical Waste",
        "Arrived",
        "98492.0",
        "Mundra",
        "Durban"
      ],
      "line": 11
    },
    {
      "cells": [
        "Music Player",
        "Pending",
        "68463.0",
        "Kobe",
        "Osaka"
      ],
      "line": 12
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition5.initialize_the_firefox_driver_and_navigate_to_the_shipment_page()"
});
formatter.result({
  "duration": 5226804254,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition5.get_the_page_element_and_click_on_it()"
});
formatter.result({
  "duration": 193110467,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition5.verify_if_the_element_present_with_tag_and_the_related_data_are_present_and_close_the_driver_with_quit_method(DataTable)"
});
formatter.result({
  "duration": 2581083440,
  "status": "passed"
});
});