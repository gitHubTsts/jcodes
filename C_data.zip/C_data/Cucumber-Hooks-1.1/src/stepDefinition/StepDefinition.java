package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.*;
import cucumber.api.java.en.*;


public class StepDefinition {
	
	WebDriver driver;
	String text;
	
	@Before
	public void setUp(){		
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	
	@Given("^User loads the application and DATAX shipping company screen appears$")
	public void loadUrl(){
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CostCalculation/");	    
		System.out.println("Application is launched");
	}

	@When("^User enters Weight \"([^\"]*)\" and selects Transport Mode \"([^\"]*)\" on shipping cost calculation page$")
	public void testCalculateCost(String weight, String element){
		driver.findElement(By.id("weight")).sendKeys(weight);
		driver.findElement(By.id(element)).click();
		driver.findElement(By.id("premium")).click();
		driver.findElement(By.id("calculate")).click();
	}

	@Then("^Validate the Shipping cost message displayed on the screen$")
	public void validateResult() {
	    text = driver.findElement(By.xpath("//div[@id='result']")).getText();
	    System.out.println(text);
	}
	
	
	@After
	public void tearDown(){
		driver.quit();
	}
}
	
	
