package stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.*;


public class StepDefinition {

	WebDriver driver;
	String text;

	@Given("^User loads the application and navigate to home page$")
	public void setUp(){		
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/Handling_Reg_Expression");
		System.out.println("Application is launched");
	}

	@When("^User enters \"([^\"]*)\" on the tracking page and clicks Search button$")
	public void testUserDetails(String Name){
		driver.findElement(By.id("userId")).sendKeys(Name);
		driver.findElement(By.id("track")).click();
	}

	@Then("^the following details should be displayed$")
	public void validateResult(DataTable ShipmentDetails) {
		List<List<String>> data = ShipmentDetails.raw();
		String Name = data.get(1).get(0);
		String ShipmentID = data.get(1).get(1);
		String PhoneNumber = data.get(1).get(2);
		String EmailID = data.get(1).get(3);
		
	    text = driver.findElement(By.xpath("//div[@id='result']")).getText();
	    if(text.contains(Name) && text.contains(ShipmentID) && text.contains(PhoneNumber) && text.contains(EmailID)){
	    	System.out.println("The name,shipmentid,phone number,e-mailId are displayed.");
	    }
	    else 
	    	System.out.println("The name,shipmentid,phone number,e-mailId are not displayed.");
	}
	
	@After
	public void closeDriver(){
		driver.quit();
	}
}


